# bot_discord


## token du bot
pour faire fonctioner le bot il faut rajouter un fichier : 
  - config
    et mettre dedans :
      - TOKEN=votreToken

## modifiction a faire
dans les fichier :
  - pendu.py [l : 24]
  - python_execute.py[l: 17]

  il y a les id des channels qu'il faut changer en fonction de votre server

